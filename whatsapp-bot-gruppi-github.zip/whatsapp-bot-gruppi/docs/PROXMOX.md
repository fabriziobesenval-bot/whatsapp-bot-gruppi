# Installare il bot su Proxmox

Il bot gira in un container Debian (LXC) e usa Ollama, l'AI gratuita: quello che hai già, oppure uno nuovo installato nello stesso container. Si avvia da solo all'accensione di Proxmox e riparte da solo se si blocca. Il pannello bozze si apre da qualsiasi PC di casa.

## 1. Crea il container

Nell'interfaccia di Proxmox:

1. Prima scarica il template: **local → CT Templates → Templates** e scegli **debian-12-standard** (o debian-13).
2. Poi **Create CT**:
   - **General:** hostname `whatsapp-bot`, imposta una password di root. Lascia spuntato *Unprivileged container*.
   - **Template:** quello Debian appena scaricato
   - **Se usi un Ollama che hai già:** 2 core, 2048 MB di RAM, 10 GB di disco
   - **Se Ollama va installato qui:** 4 core, 10240 MB di RAM, 25 GB di disco (Ollama lavora con la CPU: più core, risposte più veloci)
   - **Swap:** 1024 MB
   - **Network:** DHCP, oppure un IP fisso (comodo per il pannello)
3. Fine, poi avvia il container.

> Se il server ha poca RAM libera, usa il modello leggero `gemma4:e2b`: bastano circa 6 GB.

## 2. Scarica il bot nel container

Apri la **Console del container** (oppure `pct enter 105` dalla shell del nodo: `105` è un esempio, usa l'ID del tuo container) e scarica il repository:

```
apt update && apt install -y git curl
cd /root
git clone https://github.com/<utente>/whatsapp-bot-gruppi.git   # indirizzo dal pulsante verde «Code»
cd whatsapp-bot-gruppi
```

## 3. Installa

Resta nella stessa console, dentro la cartella `whatsapp-bot-gruppi`.

**Se hai già Ollama su Proxmox** (in un altro container o VM), usa quello. Al posto dell'IP metti l'indirizzo della macchina con Ollama:

```
bash installa-proxmox.sh --ollama http://10.0.0.20:11434
```

In questo caso il container del bot può essere piccolo: 2 core, 2 GB di RAM, 10 GB di disco.
Se il modello `gemma4:e4b` non c'è, lo script lo fa scaricare al tuo Ollama. Per usarne uno che hai già, aggiungi il suo nome alla fine, per esempio `bash installa-proxmox.sh --ollama http://10.0.0.20:11434 qwen3:8b` (la lista dei modelli la vedi con `ollama list`).

> Ollama di solito accetta solo richieste da sé stesso. Se lo script dice che non risponde, vai sulla macchina di Ollama e scrivi `systemctl edit ollama`. Nello spazio libero aggiungi:
> ```
> [Service]
> Environment="OLLAMA_HOST=0.0.0.0:11434"
> ```
> salva, poi `systemctl restart ollama` e rilancia lo script.

**Se invece non hai Ollama**, lo installa lo script nello stesso container:

```
bash installa-proxmox.sh
```

Per usare il modello leggero: `bash installa-proxmox.sh gemma4:e2b`

Lo script installa Node.js e Chromium (più Ollama, se serve) e crea il servizio di avvio automatico. Alla fine stampa l'indirizzo del pannello e la password.

## 4. Collega WhatsApp

1. Dal PC apri il pannello, per esempio `http://10.0.0.30:3001`. Come utente scrivi quello che vuoi, poi la password che ti ha dato lo script.
2. Sul telefono apri WhatsApp → **Dispositivi collegati → Collega un dispositivo** e inquadra il QR mostrato nel pannello.
3. Se prima avevi avviato il bot anche sul PC Windows, chiudilo e togli quel collegamento dai *Dispositivi collegati*, così non rispondono in due.

## 5. Configura i gruppi

```
nano /opt/whatsapp-bot/gruppi.json
```

È lo stesso file spiegato in GUIDA.md. Le modifiche valgono subito, senza riavviare.
Per salvare in nano premi `Ctrl+O`, poi Invio; per uscire `Ctrl+X`.

## Comandi utili (nella console del container)

| Cosa | Comando |
|---|---|
| Vedere cosa fa il bot in tempo reale | `journalctl -u whatsapp-bot -f` |
| Riavviarlo | `systemctl restart whatsapp-bot` |
| Fermarlo / avviarlo | `systemctl stop whatsapp-bot` / `systemctl start whatsapp-bot` |
| Cambiare impostazioni | `nano /opt/whatsapp-bot/config.json`, poi riavvia |
| Aggiornare la libreria WhatsApp | `cd /opt/whatsapp-bot && PUPPETEER_SKIP_DOWNLOAD=1 npm update whatsapp-web.js && chown -R wabot:wabot . && systemctl restart whatsapp-bot` |

**Aggiornare il bot:** `cd /root/whatsapp-bot-gruppi && git pull && bash installa-proxmox.sh` (con le stesse opzioni della prima volta). Le tue impostazioni (`config.json` e `gruppi.json`) e il collegamento a WhatsApp vengono mantenuti.

**Backup:** includi il container nei backup di Proxmox (Datacenter → Backup), così salvi anche il collegamento a WhatsApp e le impostazioni.
