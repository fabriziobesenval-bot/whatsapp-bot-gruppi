# Bot WhatsApp per le chat di gruppo

Il bot apre WhatsApp Web sul PC, legge i tuoi gruppi e, gruppo per gruppo, fa una di queste cose:

| modalita  | cosa fa |
|-----------|---------|
| `off`     | ignora il gruppo (è l'impostazione iniziale di tutti) |
| `auto`    | risponde da solo con l'AI |
| `approva` | prepara una bozza: la approvi dal pannello sul PC o dal telefono |

## 1. Installazione (una volta sola)

Tutto gratuito, niente abbonamenti.

1. Installa **Node.js** (versione 18 o successiva) da https://nodejs.org
2. Installa **Ollama** da https://ollama.com (è l'AI che gira sul tuo PC, gratis e senza limiti; i messaggi non escono da casa).
3. Apri il Prompt dei comandi e scarica il modello (circa 4-5 GB, una volta sola):
   ```
   ollama pull gemma4:e4b
   ```
   Serve un PC con almeno 8 GB di RAM. Se è lento, prova il più leggero `gemma4:e2b`; se hai una buona scheda video puoi provarne uno più grande. Il nome del modello si cambia in `config.json` → `ollama` → `modello`.
4. Fai doppio clic su **`avvia.bat`**. Alla prima volta installa i componenti (qualche minuto, scarica anche un Chrome interno). Nella finestra deve comparire `AI: Ollama, modello gemma4:e4b ✅`.

### In alternativa: Gemini (gratis, ma con limiti)

Se il PC è troppo lento per Ollama, puoi usare il piano gratuito di Google Gemini:
crea una chiave gratuita su https://aistudio.google.com (senza carta di credito), poi in `config.json` metti `"ai": "gemini"` e incolla la chiave in `gemini` → `apiKey`.
Attenzione: c'è un limite di richieste al giorno e, sul piano gratuito, Google può usare i testi inviati (cioè i messaggi dei gruppi) per migliorare i suoi modelli. Non collegare mai un metodo di pagamento a quel progetto, così resta gratuito.

## 2. Collegamento a WhatsApp

Quando compare il QR code (nella finestra nera o nel pannello http://localhost:3001):
telefono → WhatsApp → **Impostazioni → Dispositivi collegati → Collega un dispositivo** → inquadra.

Il collegamento resta salvato nella cartella `.sessione`: agli avvii successivi non serve più il QR.

## 3. Configurare i 16 gruppi

Al primo collegamento il bot scrive in `gruppi.json` tutti i tuoi gruppi, **spenti**. Aprilo con il Blocco note e, per ogni gruppo che ti interessa, cambia i valori. Esempio:

```json
"120363012345678901@g.us": {
  "nome": "Circolo del tennis",
  "modalita": "approva",
  "quando": "menzione",
  "parole": [],
  "istruzioni": "È il gruppo del circolo. Gli allenamenti sono il martedì e il giovedì alle 19. Per iscrizioni e tornei rimanda al sito del circolo.",
  "maxOra": 5
},
"120363098765432109@g.us": {
  "nome": "Calcetto giovedì",
  "modalita": "auto",
  "quando": "parole",
  "parole": ["chi viene", "ci sei", "fabri"],
  "istruzioni": "Mario di solito c'è. Rispondi in modo scherzoso.",
  "maxOra": 3
}
```

- **quando**
  - `menzione` – solo quando ti taggano, rispondono a un tuo messaggio o scrivono il tuo nome (consigliato)
  - `parole` – quando nel messaggio compare una delle `parole`
  - `sempre` – valuta ogni messaggio (l'AI risponde solo se serve, ma usalo con cautela)
- **istruzioni** – cosa deve sapere il bot su quel gruppo e con che tono rispondere
- **maxOra** – numero massimo di risposte (o bozze) all'ora in quel gruppo

Le modifiche a `gruppi.json` valgono subito, senza riavviare il bot.

In `config.json` puoi cambiare il tuo nome, lo stile generale (`istruzioniGenerali`), le pause prima di rispondere e una `firma` facoltativa da aggiungere a ogni risposta (es. `"🤖 risposta automatica"`).

### Avviso "Assistente IA" quando non rispondi

Per far scrivere al bot un avviso quando in un gruppo ti scrivono e tu non rispondi, aggiungi al gruppo in `gruppi.json`:

```json
"assenza": { "attivo": true, "dopoMessaggi": 2, "dopoMinuti": 5, "pausaOre": 6 }
```

Dopo 2 messaggi senza una tua risposta, e almeno 5 minuti dopo il primo, il bot scrive: *"🤖 Ciao, sono l'Assistente IA di Mario: in questo momento non riesce a rispondere, lo farà appena possibile."* L'avviso parte una volta sola: si riattiva dopo che hai scritto tu nel gruppo, al massimo uno ogni 6 ore. Con `"testo": "..."` puoi cambiare il messaggio. Funziona anche se la `modalita` del gruppo è `off`.

## 4. Approvare le bozze

- **Dal PC:** pannello http://localhost:3001 → modifichi il testo se vuoi → **Invia** o **Scarta**.
- **Dal telefono:** ogni bozza ti arriva nella chat **"Messaggi a te stesso"**. Rispondi lì con:
  - `si 12` → invia la bozza 12 così com'è
  - `no 12` → la scarta
  - `mod 12 testo nuovo` → invia il tuo testo al posto della proposta

  (Se non vuoi i messaggi sul telefono, metti `"notificaSuTelefono": false` in `config.json`.)

## Da sapere

- Con Ollama le risposte su un PC senza scheda video possono richiedere 10-60 secondi: per WhatsApp va benissimo, sembra una persona che scrive.
- Il PC deve restare **acceso con il bot avviato** (e Ollama attivo). Per fermarlo chiudi la finestra o premi `Ctrl+C`.
- È un'automazione **non ufficiale** di WhatsApp Web: WhatsApp può bloccare il numero se nota un comportamento da bot. Il bot riduce il rischio con pause casuali, simulazione della scrittura, risposta unica a raffiche di messaggi e limite orario, ma il rischio non è zero. Parti con pochi gruppi in `approva` e passa ad `auto` gradualmente.
- Se un giorno il bot non si collega più (WhatsApp Web cambia spesso), aggiorna la libreria: apri il prompt nella cartella e scrivi `npm update whatsapp-web.js`.
- Per scollegare il bot: telefono → Dispositivi collegati → esci dal dispositivo, poi cancella la cartella `.sessione`.
